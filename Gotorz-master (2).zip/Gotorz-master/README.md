Eksamensprojekt 3. Semester Team12: Gotorz .\
\
Forudsætninger for at køre programmet:\
Opret appsettings.JSON .\
Tilføj connectionstring til database .\
Tilføj API-key + Secret-key til brug af Amadeus API'er .\
Tilføj API-key + Secret-key til brug af Stripe\
Nøgler og secrets kan findes i den tilsendte .PDF fil , database skal oprettes personligt .\
\
Denne solution består af fire projekter:\
Gotorz .\
Gotorz.Client .\
Shared .\
Gotorz.Tests.Server .\
\
Gotorz er vores ASP .NET Core backend .\
Gotorz.Client er vores Blazor WASM frontend .\
Shared er vores delte model lag .\
Gotorz.Tests.Server er vores unit og integration tests .\
\
I mappen /Diagrammer/ kan vores LLD artefakter findes.
